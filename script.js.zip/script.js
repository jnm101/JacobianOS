setInterval(load, 1);
var loaded = 0;
function load() {
    
    if (loaded < 100) {
        loaded+= 0.1;
    }
    document.getElementById('inLoad').style.width = loaded + '%';
    if (loaded>=100) {
        document.getElementById('loadScreen').style.display = 'none';
        document.getElementById('afterLoad').style.display = 'block';
        
    }
}